﻿#region PageSummary
// *****************************************************************
// Project:        MAQWebService
// Solution:       WebApi
//
// Author:  MAQ Software
// Date:    November 17, 2016
// Description: Class used to log all the errors on SQL Azure. 
// Change History:
// Name                         Date                    Version        Description
// -------------------------------------------------------------------------------
// Developer               November 17, 2016           1.0.0.0       Event based error logging mechanism.
// -------------------------------------------------------------------------------
// Copyright (C) MAQ Software
// -------------------------------------------------------------------------------
#endregion

namespace $safeprojectname$
{
    #region Using
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.Text;
    #endregion
    /// <summary>
    /// Event Logger is used to log events in windows Event viewers. 
    /// </summary>
    internal static class EventLogger
    {
        /// <summary>
        /// Logs the specified error.
        /// </summary>
        /// <param name="message">Message received to log an error.</param>
        /// <param name="eventLogEntryType">Type of the event log entry.</param>
        internal static void LogMessage(string message, EventLogEntryType eventLogEntryType)
        {
            if (!string.IsNullOrWhiteSpace(message))
            {
                string type = Constants.LOG_LEVEL_INFO;
                switch (eventLogEntryType)
                {
                    case EventLogEntryType.Error:
                        type = Constants.LOG_LEVEL_ERROR;
                        break;
                    case EventLogEntryType.FailureAudit:
                        type = Constants.LOG_LEVEL_FAILURE_AUDIT;
                        break;
                    case EventLogEntryType.SuccessAudit:
                        type = Constants.LOG_LEVEL_SUCCESS;
                        break;
                    case EventLogEntryType.Warning:
                        type = Constants.LOG_LEVEL_WARNING;
                        break;
                    case EventLogEntryType.Information:
                        type = Constants.LOG_LEVEL_INFO;
                        break;
                    default:
                        type = Constants.LOG_LEVEL_INFO;
                        break;
                }
                AddToEventViewer(message, eventLogEntryType, type);
            }
        }

        /// <summary>
        /// Writes the log message for specified exception.
        /// </summary>
        /// <param name="exception">Exception object</param>
        internal static void LogException(Exception exception)
        {
            if (null != exception)
            {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.AppendFormat(CultureInfo.InvariantCulture,
                                Constants.LOGGER_EXCEPTION_MESSAGE,
                                exception.Message,             //0
                                Environment.NewLine,           //1
                                exception.Source,              //2
                                exception.InnerException,      //3
                                exception.StackTrace           //4
                               );
                EventLogEntryType entryType = EventLogEntryType.Error;
                EventLogger.LogMessage(Convert.ToString(stringBuilder, CultureInfo.InvariantCulture), entryType);
            }
        }
        /// <summary>
        /// This function logs error message to specified text file
        /// </summary>
        /// <param name="errorMessage">Error message to be logged</param>
        /// <param name="eventLogEntryType">Error message to be logged</param>
        /// <param name="type">Type of Error generated</param>
        public static void AddToEventViewer(string errorMessage, EventLogEntryType eventLogEntryType, string type)
        {
            // Create an EventLog instance and assign its source.
            EventLog eventLog = new EventLog();
            try
            {
                if (!string.IsNullOrWhiteSpace(errorMessage) && !string.IsNullOrWhiteSpace(type))
                {
                    if (!EventLog.SourceExists(Constants.EVENT_SOURCE))
                    {
                        EventLog.CreateEventSource(Constants.EVENT_SOURCE, Constants.EVENT_LOG);
                    }
                    // Setting the source
                    eventLog.Source = Constants.EVENT_SOURCE;
                    // Write an entry to the event log.
                    eventLog.WriteEntry(errorMessage, eventLogEntryType, Constants.EVENT_ID);
                }
            }
            finally
            {
                eventLog.Close();
            }
        }
    }
}