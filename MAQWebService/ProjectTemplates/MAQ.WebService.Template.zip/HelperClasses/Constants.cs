﻿#region PageSummary
// *****************************************************************
// Project:        MAQWebService
// Solution:       WebApi
//
// Author:  MAQ Software
// Date:    November 17, 2016
// Description: Class containing constant values for variables throughout the project 
// Change History:
// Name                         Date                    Version        Description
// -------------------------------------------------------------------------------
// Developer               November 17, 2016           1.0.0.0       Class containing constant values for variables throughout the project 
// -------------------------------------------------------------------------------
// Copyright (C) MAQ Software
// -------------------------------------------------------------------------------
#endregion
namespace $safeprojectname$
{
    #region using
    using System;
    using System.Configuration;
    using System.Globalization;
    #endregion
    /// <summary>
    /// A Constants class used to define the literal to be used throughout the API.
    /// </summary>
    internal static class Constants
    {
        #region Web.CONFIG Keys
        /// <summary>
        /// CORSOrigins is a constant value retrieved from Web config attribute "CORSOrigins". 
        /// This attribute contains value required for a server to explicitly allow cross-origin requests while rejecting others
        /// </summary>

        internal static readonly string CORS_ORIGINS = ConfigurationManager.AppSettings["CORSOrigins"];
        /// <summary>
        /// Defines the Media type used to describe the format of the message body
        /// </summary>

        internal static readonly string SUPPORTED_MEDIA_TYPE = ConfigurationManager.AppSettings["SupportedMediaType"];
        ///// <summary>
        ///// Defines the content-type header orthogonal to the HTTP POST method 
        ///// </summary>
        //internal static readonly string NULL_SUPPORTED_MEDIA_TYPE = ConfigurationManager.AppSettings["NullSupportedMediaType"];

        ///// <summary>
        ///// Defines Bad Request response from server.
        ///// </summary>
        //internal static readonly string SERVER_RESPONSE_MESSAGE = ConfigurationManager.AppSettings["400ServerResponse"];

        ///// <summary>
        ///// Defines Success response from server.
        ///// </summary>
        //internal static readonly string PING_RESPONSE = ConfigurationManager.AppSettings["200PingResponse"];
        #endregion

        #region Azure Logger
        /// <summary>
        ///  Date Key format used for exception logging
        /// </summary>
        internal static string AZURE_ROW_DATE_KEY_FORMAT = "MM-dd-yyyy HH:mm:ss:fffffff";

        /// <summary>
        /// Provides connection string for Azure connection.
        /// </summary>
        internal static readonly string AZURE_CONNECTION = ConfigurationManager.AppSettings["AzureConnection"];

        /// <summary>
        /// Provides the name of table to be used to log error on Azure SQL database
        /// </summary>
        internal static readonly string ERROR_LOG_TABLE = ConfigurationManager.AppSettings["ErrorLogTable"];
        #endregion

        #region Error Configurations
        /// <summary>
        ///  String literal for Log level Error
        /// </summary>
        internal static string LOG_LEVEL_ERROR = "Error";

        /// <summary>
        ///  String literal for Log level FailureAudit
        /// </summary>
        internal static string LOG_LEVEL_FAILURE_AUDIT = "FailureAudit";

        /// <summary>
        ///  String literal for Log level Success
        /// </summary>
        internal static string LOG_LEVEL_SUCCESS = "Success";

        /// <summary>
        ///  String literal for Log level Warning
        /// </summary>
        internal static string LOG_LEVEL_WARNING = "Warning";

        /// <summary>
        ///  String literal for Log level INFO
        /// </summary>
        internal static string LOG_LEVEL_INFO = "INFO";

        /// <summary>
        /// Consist of Exception Message 
        /// </summary>
        internal static string LOGGER_EXCEPTION_MESSAGE = "Exception Message: {0}.{1}Exception Source: {2}.{1}Exception Inner Exception: {3}.{1}Exception Stack: {4};";
        #endregion

        #region Constants
        /// <summary>
        /// String Place holders
        /// </summary>
        internal static string PLACE_HOLDER = "{0} - {1}";

        /// <summary>
        /// String literal closing bracket
        /// </summary>
        internal static string CLOSING_BRACKET = "}";

        /// <summary>
        /// PreflightMaxAge stores the number of seconds the results of a preflight request can be cached
        /// </summary>
        internal static readonly string PRE_FLIGHT = ConfigurationManager.AppSettings["PreflightMaxAge"];

        /// <summary>
        /// Defines servers for which CORS Origins are allowed
        /// </summary>
        internal static readonly string ALLOWED_ORIGINS = ConfigurationManager.AppSettings["AllowedOrigins"];

        /// <summary>
        /// String semicolon
        /// </summary>
        internal static string SEMI_COLON = ";";

        /// <summary>
        ///  Defines the name of route map used by HTTPRouteCollection
        /// </summary>
        internal static string HTTP_ROUTE_NAME = "DefaultApi";

        /// <summary>
        ///  Defines the Route Template used by HTTPRouteCollection
        /// </summary>
        internal static string HTTP_ROUTE_TEMPLATE = "api/{controller}/{id}";

        /// <summary>
        ///  String literal Register
        /// </summary>
        public const string REGISTER = "Register";

        /// <summary>
        ///  String literal Path
        /// </summary>
        internal static string PATH = @"bin\OutputXML.xml";

        /// <summary>
        /// Path that needs to be ignored by Route configuration.
        /// </summary>
        internal static string INVALID_ROUTE = "{resource}.axd/{*pathInfo}";

        /// <summary>
        /// Path that needs to be accepted by Route configuration.
        /// </summary>
        internal static string VALID_ROUTE = "{controller}/{action}/{id}";

        /// <summary>
        /// String literal Default name for map route
        /// </summary>
        internal static string DEFAULT_MAP_ROUTE = "Default";

        /// <summary>
        /// String literal Default value for controller
        /// </summary>
        internal static string DEFAULT_CONTROLLER_NAME = "Home";

        /// <summary>
        /// String literal Default value for controller
        /// </summary>
        internal static string DEFAULT_CONTROLLER_INDEX = "Index";

        /// <summary>
        /// Error Message for Get
        /// </summary>
        internal static string ERROR_GET = "GET: Test message";

        /// <summary>
        /// Error Message for Post
        /// </summary>
        internal static string ERROR_POST = "POST: Test message";

        /// <summary>
        /// Swagger Error Message for Get
        /// </summary>
        internal static string ERROR_GET_SWAGGER = "GET: SWAGGER Test message";

        /// <summary>
        /// Swagger Error Message for POST
        /// </summary>
        internal static string ERROR_POST_SWAGGER = "POST: SWAGGER Test message";

        /// <summary>
        /// Success message for Swagger
        /// </summary>
        internal static string SWAGGER_MESSAGE = "Test Data Updated";

        /// <summary>
        /// Swagger Version
        /// </summary>
        internal static string SWAGGER_VERSION = "v1";

        /// <summary>
        /// Swagger Title
        /// </summary>
        internal static string SWAGGER_TITLE = "Web API";

        /// <summary>
        /// Swagger Version
        /// </summary>
        internal static string DEMO_STRING = "This is a Demo string for Test Controller!!";
        #endregion

        #region EventLogger
        /// <summary>
        /// Contains the name for Event Logger file
        /// </summary>
        internal static string EVENT_SOURCE = ConfigurationManager.AppSettings["EventSource"];

        /// <summary>
        /// Contains the name for Event Logger file
        /// </summary>
        internal static string EVENT_LOG = ConfigurationManager.AppSettings["EventLog"];

        /// <summary>
        /// Application defined event identifier for event log
        /// </summary>
        internal static int EVENT_ID = Convert.ToInt32(ConfigurationManager.AppSettings["EventId"], CultureInfo.InvariantCulture);
        #endregion

        #region Export to Excel 
        /// <summary>
        /// Set Headers for Excel file
        /// </summary>
        internal static string EXCEL_HEADERS = "Id;First Name;Last Name";

        /// <summary>
        /// Content type(Excel extension)
        /// </summary>
        internal static string CONTENT_TYPE = "xlsx";

        /// <summary>
        /// Char data-type semicolon
        /// </summary>
        internal static char CHAR_SEMICOLON = ';';

        /// <summary>
        /// Char data-type new line
        /// </summary>
        internal static char CHAR_NEWLINE = '\n';

        /// <summary>
        /// Excel sheet name
        /// </summary>
        internal static string SHEET_NAME = "Sheet1";

        /// <summary>
        /// Contains value for HTTP Content
        /// </summary>
        internal static string HTTP_CONTENT = "content";

        /// <summary>
        /// Exception for No values available to create an excel.
        /// </summary>
        internal static string EXCEL_EXCEPTION = "No value available";

        /// <summary>
        /// Excel file name
        /// </summary>
        internal static string EXCEL_FILENAME = "ExportExcel";

        /// <summary>
        /// Excel header name
        /// </summary>
        internal static string EXCEL_HEADER_NAME = "content-disposition";

        /// <summary>
        /// Excel header value 
        /// </summary>
        internal static string EXCEL_HEADER_VALUE = "attachment;filename={0}_{1}.xlsx";

        /// <summary>
        /// Date format for file name
        /// </summary>
        internal static string EXPORT_TO_EXCEL_FILENAME_DATEFORMAT = "yyyyMMdd_HHmmss";

        /// <summary>
        /// Date format for file name
        /// </summary>
        internal static string ZERO_PLACEHOLDER = "{0:";

        /// <summary>
        /// String literal Pipe Separator
        /// </summary>
        internal static string PIPE_SEPARATOR = "|";

        /// <summary>
        /// Char data-type new line
        /// </summary>
        internal static string NEWLINE = "\n";
        #endregion

        #region Export to Excel Service
        /// <summary>
        /// Folder name to read Excel file
        /// </summary>
        internal static string EXCEL_FOLDERNAME = "ReadFiles";

        /// <summary>
        /// File name to read Excel 
        /// </summary>
        internal static string EXCEL_FILE = "ExportToExcel.xlsx";

        /// <summary>
        /// Set Excel Media types to Office document.
        /// </summary>
        internal static string EXCEL_MEDIA_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

        /// <summary>
        /// Set Excel Media types to Office document.
        /// </summary>
        internal static string EXCEL_DISPOSITIONTYPE = "attachment";

        #endregion

    }
}