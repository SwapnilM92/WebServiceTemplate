﻿#region PageSummary
// *****************************************************************
// Project:        MAQWebService
// Solution:       WebApi
//
// Author:  MAQ Software
// Date:    November 17, 2016
// Description: Class used to log all the errors on SQL Azure. 
// Change History:
// Name                         Date                    Version        Description
// -------------------------------------------------------------------------------
// Developer               November 17, 2016           1.0.0.0       Cloud based SQL Azure error logging mechanism.
// -------------------------------------------------------------------------------
// Copyright (C) MAQ Software
// -------------------------------------------------------------------------------
#endregion
namespace $safeprojectname$
{
    #region usings
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.Text;
    using Microsoft.WindowsAzure.Storage;
    using Microsoft.WindowsAzure.Storage.Table;
    #endregion
    /// <summary>
    /// Class Logger is used to log events in Azure SQL database in case of failures. 
    /// </summary>
    internal static class AzureLogger
    {
        /// <summary>
        /// Logs the specified error.
        /// </summary>
        /// <param name="message">Message received to log an error.</param>
        /// <param name="eventLogEntryType">Type of the event log entry.</param>
        internal static void LogMessage(string message, EventLogEntryType eventLogEntryType)
        {
            if (!string.IsNullOrWhiteSpace(message))
            {
                string type = Constants.LOG_LEVEL_INFO;
                switch (eventLogEntryType)
                {
                    case EventLogEntryType.Error:
                        type = Constants.LOG_LEVEL_ERROR;
                        break;
                    case EventLogEntryType.FailureAudit:
                        type = Constants.LOG_LEVEL_FAILURE_AUDIT;
                        break;
                    case EventLogEntryType.SuccessAudit:
                        type = Constants.LOG_LEVEL_SUCCESS;
                        break;
                    case EventLogEntryType.Warning:
                        type = Constants.LOG_LEVEL_WARNING;
                        break;
                    case EventLogEntryType.Information:
                        type = Constants.LOG_LEVEL_INFO;
                        break;
                    default:
                        type = Constants.LOG_LEVEL_INFO;
                        break;
                }
                AddtoTable(message, type);
            }
        }
        /// <summary>
        /// Writes the log message for specified exception.
        /// </summary>
        /// <param name="exception">Exception object</param>
        internal static void LogException(Exception exception)
        {
            if (null != exception)
            {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.AppendFormat(CultureInfo.InvariantCulture,
                                Constants.LOGGER_EXCEPTION_MESSAGE,
                                exception.Message,             //0
                                Environment.NewLine,           //1
                                exception.Source,              //2
                                exception.InnerException,      //3
                                exception.StackTrace           //4
                               );
                EventLogEntryType entryType = EventLogEntryType.Error;
                AzureLogger.LogMessage(Convert.ToString(stringBuilder, CultureInfo.InvariantCulture), entryType);
            }
        }
        /// <summary>
        /// This function logs error message to table in Azure SQL
        /// </summary>
        /// <param name="type">Event type of an Error</param>
        /// <param name="errorMessage">Error message to be logged</param>
        public static void AddtoTable(string errorMessage, string type)
        {
            if (!string.IsNullOrWhiteSpace(errorMessage) && !string.IsNullOrWhiteSpace(type))
            {
                string azureConnectionString = Constants.AZURE_CONNECTION;
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(azureConnectionString);
                CloudTableClient client = storageAccount.CreateCloudTableClient();
                CloudTable table = client.GetTableReference(Constants.ERROR_LOG_TABLE);
                try
                {
                    table.CreateIfNotExists();
                    TableEntity tableEntityObj = new TableEntity();
                    tableEntityObj.PartitionKey = String.Concat(type, ": ", errorMessage);
                    string date = DateTime.Now.ToUniversalTime().ToString(Constants.AZURE_ROW_DATE_KEY_FORMAT, CultureInfo.InvariantCulture);
                    tableEntityObj.RowKey = string.Format(CultureInfo.InvariantCulture, Constants.PLACE_HOLDER, date, Guid.NewGuid());
                    // Below line can be uncommented to log error message in Log table.
                    //tableEntityObj.LogMessage = errorMessage;
                    TableOperation insertOp = TableOperation.Insert(tableEntityObj);
                    table.Execute(insertOp);
                }
                catch
                {
                    // Do nothing here
                }
                finally
                {
                    // Garbage collector
                    storageAccount = null;
                    client = null;
                }
            }
        }
    }
}