﻿#region PageSummary
// *****************************************************************
// Project:        MAQWebService
// Solution:       WebApi
//
// Author:  MAQ Software
// Date:    November 25, 2016
// Description: To download or export the excel file, we use this service.
//
// Change History:
// Name                         Date                    Version        Description
// -------------------------------------------------------------------------------
// Developer               March 08, 2017          1.0.0.0       Web Service to download the excel file.
// -------------------------------------------------------------------------------
// Copyright (C) MAQ Software
// -------------------------------------------------------------------------------
#endregion
namespace $safeprojectname$
{
    #region using
    using System;
    using System.IO;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Web.Http;
    #endregion
    /// <summary>
    /// Controller to export data to Excel
    /// </summary>
    public class ExportToExcelController : ApiController
    {
        /// <summary>
        /// Controller to download the Excel file.
        /// </summary>
        /// <returns>HttpResponseMessage</returns>
        [HttpPost]
        [Route("api/Export")]
        public HttpResponseMessage Export()
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Constants.EXCEL_FOLDERNAME, Constants.EXCEL_FILE);
            FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read);
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                if (1 <= fileStream.Length)
                {
                    response.Content = new StreamContent(fileStream);
                    response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue(Constants.EXCEL_DISPOSITIONTYPE); // ?
                    response.Content.Headers.ContentDisposition.FileName = Constants.EXCEL_FILE;//your file Name- text.xls
                    response.Content.Headers.ContentType = new MediaTypeHeaderValue(Constants.EXCEL_MEDIA_TYPE);
                    response.Content.Headers.ContentLength = fileStream.Length;
                    response.StatusCode = System.Net.HttpStatusCode.OK;
                    return response;
                }
                else
                {
                    return response;
                }
            }
            catch
            {
                // Do something here
                return response;
            }
        }
    }
}
